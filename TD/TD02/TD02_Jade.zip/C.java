public class C {
    private int a;

    public C (int a) {
        this.a = a;
    }
    public String toString() {
        return Integer.toString(a);
    }
    public void setNumber(int j) {
        this.a = j;
    }
}
