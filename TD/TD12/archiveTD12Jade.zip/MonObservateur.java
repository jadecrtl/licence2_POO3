public interface MonObservateur {
    void update(MonObservateur o, Object arg);
    
}
