public class EntreeSpeciale extends Entree{
    
    public EntreeSpeciale(Dossier p, String n, Element e) {
		super(p, n, e);
	}
}
