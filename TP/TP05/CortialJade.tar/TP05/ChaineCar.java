public class ChaineCar{
    String carac;

    public int len() {
        int len=0;
        return len;
    }

    public String toString() {
        String l="";
        return l;
    }

}