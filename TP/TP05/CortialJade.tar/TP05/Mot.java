
public class Mot extends ChaineCar{
	String mot;
	
	public Mot(String mot) {
		this.mot=mot;
	}
	
	public int len() {
		int len=this.mot.length();
		return len;
	}
	
	public String toString() {
		String l=this.mot;
		return l;
	}

}
