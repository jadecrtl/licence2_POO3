public interface StringTransformation {
    
    public String transf(String s);


}
