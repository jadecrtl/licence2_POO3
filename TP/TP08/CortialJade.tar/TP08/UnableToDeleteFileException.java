public class UnableToDeleteFileException extends Exception {

	public UnableToDeleteFileException(String string) {
		super(string);
	}

}
