
public class Circle extends Ellipse {

	public Circle(int x, int y, double gr) {
		super(x, y, gr, gr);
	}
	
}
