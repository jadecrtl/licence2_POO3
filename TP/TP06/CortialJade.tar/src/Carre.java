
public class Carre extends Rectangle {

	public Carre(int x, int y, double lon) {
		super(x, y, lon, lon);
	}
	
}
