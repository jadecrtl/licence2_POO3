
public interface Deformable {
	public Figure deformation(double coeffH, double coeffV);
}
