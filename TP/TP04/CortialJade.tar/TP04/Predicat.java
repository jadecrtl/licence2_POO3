public class Predicat {
	
	boolean estVrai(Media m) {
		return false;
	}
}
